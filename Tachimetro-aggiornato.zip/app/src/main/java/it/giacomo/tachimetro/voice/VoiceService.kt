package it.giacomo.tachimetro.voice

import android.Manifest
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone as P
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import it.giacomo.tachimetro.CameraAlert
import it.giacomo.tachimetro.Hub
import it.giacomo.tachimetro.IncomingCall
import it.giacomo.tachimetro.IncomingMessage
import it.giacomo.tachimetro.MainActivity
import it.giacomo.tachimetro.R
import it.giacomo.tachimetro.Screen
import it.giacomo.tachimetro.TachiApp
import it.giacomo.tachimetro.UiAction
import it.giacomo.tachimetro.VoicePhase
import it.giacomo.tachimetro.VoiceUi
import it.giacomo.tachimetro.car.Car
import it.giacomo.tachimetro.car.Dnd
import it.giacomo.tachimetro.car.PhoneHealthMonitor
import it.giacomo.tachimetro.data.AppSettings
import it.giacomo.tachimetro.data.Fuel
import it.giacomo.tachimetro.data.Gemini
import it.giacomo.tachimetro.data.Keys
import it.giacomo.tachimetro.data.Net
import it.giacomo.tachimetro.data.Place
import it.giacomo.tachimetro.data.Places
import it.giacomo.tachimetro.data.Prefs
import it.giacomo.tachimetro.data.SpeedCameras
import it.giacomo.tachimetro.data.Weather
import it.giacomo.tachimetro.media.Apps
import it.giacomo.tachimetro.media.MediaSessions
import it.giacomo.tachimetro.media.Radio
import it.giacomo.tachimetro.nav.NavController
import it.giacomo.tachimetro.notify.NotificationReader
import it.giacomo.tachimetro.notify.WhatsAppSender
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import org.vosk.android.StorageService
import android.speech.RecognitionListener as AndroidRecognitionListener
import org.vosk.android.RecognitionListener as VoskListener

/**
 * Servizio sempre attivo mentre usi Tachimetro: ascolta «Ehi Tachi» sul telefono (senza internet),
 * capisce il comando, risponde a voce e tiene d'occhio posizione, autovelox, meteo e messaggi.
 */
class VoiceService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val main = Handler(Looper.getMainLooper())
    private lateinit var speaker: Speaker
    private lateinit var health: PhoneHealthMonitor
    private var settings = AppSettings()

    private var model: Model? = null
    private var wake: SpeechService? = null
    private var free: SpeechService? = null
    private var recognizer: SpeechRecognizer? = null
    private var listeningCommand = false
    private var pausedUntil = 0L

    private val fused by lazy { LocationServices.getFusedLocationProviderClient(this) }
    private var lastWeatherAt = 0L
    private var lastWeatherPlace: Location? = null
    private var alertsMuted = false
    private val announced = HashSet<String>()

    /** Conversazione guidata sui messaggi: leggo? rispondo? cosa? invio? */
    private sealed interface Dialog {
        data class AskRead(val msg: IncomingMessage) : Dialog
        data class AskReply(val msg: IncomingMessage) : Dialog
        data class ReplyText(val msg: IncomingMessage) : Dialog
        data class ReplyConfirm(val msg: IncomingMessage, val text: String) : Dialog
        data class AskAnswer(val call: IncomingCall) : Dialog
        data class ComposeApp(val to: Contact, val text: String) : Dialog
        data class ComposeText(val to: Contact, val app: String) : Dialog
        data class ComposeConfirm(val to: Contact, val app: String, val text: String) : Dialog
        data class ComposeTo(val app: String?) : Dialog
        data class PickContact(val options: List<Contact>, val purpose: String, val app: String?, val text: String) : Dialog
        data class AskPlace(val waze: Boolean) : Dialog
        data class PickPlace(val options: List<Place>, val waze: Boolean) : Dialog
        data class ConfirmRoute(val place: Place, val waze: Boolean) : Dialog
        data class PickRadio(val options: List<String>) : Dialog
        data object Repeat : Dialog
    }

    private data class Contact(val name: String, val number: String, val id: Long = -1L)

    private var dialog: Dialog? = null
    private var dialogRetry = 0
    private val noSpeechTimeout = Runnable {
        if (!listeningCommand) return@Runnable
        recognizer?.cancel()
        stopFree()
        val d = dialog
        if (d != null) {
            listeningCommand = false
            handleDialog(d, "")
        } else {
            endCommand()
        }
    }
    /** Coda dei messaggi da annunciare; il secondo valore indica «dimmi solo chi ha scritto». */
    private val pendingMessages = ArrayDeque<Pair<IncomingMessage, Int>>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        startInForeground()
        speaker = Speaker(this)
        health = PhoneHealthMonitor(this).also { it.start() }
        MediaSessions.start(applicationContext)
        scope.launch { Prefs.flow(applicationContext).collect { settings = it } }
        scope.launch { Hub.messages.collect { onMessages(it) } }
        scope.launch { Hub.incomingCall.collect { onIncomingCall(it) } }
        startLocation()
        loadModel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_LISTEN -> main.post { onWake() }
            ACTION_SAY -> intent.getStringExtra(EXTRA_TEXT)?.let { say(it) }
        }
        // se Android chiude il servizio non lo fa ripartire da solo
        return START_NOT_STICKY
    }

    /** L'app è stata chiusa dall'elenco delle app recenti: si spegne tutto. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        Dnd.restore(this)
        NotificationReader.unbind()
        MediaSessions.stop()
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacks(noSpeechTimeout)
        stopWake()
        stopFree()
        recognizer?.destroy()
        recognizer = null
        try { fused.removeLocationUpdates(locationCallback) } catch (e: Exception) { }
        health.stop()
        speaker.shutdown()
        Radio.release()
        model?.close()
        scope.cancel()
        Hub.voice.value = VoiceUi(VoicePhase.OFF)
        super.onDestroy()
    }

    // ---------------- primo piano ----------------

    private fun startInForeground() {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val n: Notification = NotificationCompat.Builder(this, TachiApp.CH_SERVICE)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Tachimetro è attivo")
            .setContentText("Di' «Ehi Tachi» per dare un comando")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        var types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        if (granted(Manifest.permission.RECORD_AUDIO)) types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        if (granted(Manifest.permission.ACCESS_FINE_LOCATION) || granted(Manifest.permission.ACCESS_COARSE_LOCATION)) {
            types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
        }
        ServiceCompat.startForeground(this, 7, n, types)
    }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    // ---------------- parola chiave ----------------

    private fun loadModel() {
        if (!granted(Manifest.permission.RECORD_AUDIO)) {
            Hub.voice.value = VoiceUi(VoicePhase.OFF, error = "Serve il permesso del microfono")
            return
        }
        Hub.voice.value = VoiceUi(VoicePhase.LOADING)
        StorageService.unpack(
            this, "model-it", "model",
            { m ->
                model = m
                startWake()
            },
            { e ->
                Hub.voice.value = VoiceUi(VoicePhase.OFF, error = "Modello vocale non disponibile: ${e.message}")
            },
        )
    }

    private fun inCall(): Boolean {
        val am = getSystemService(AudioManager::class.java) ?: return false
        return am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION
    }

    private fun startWake() {
        val m = model ?: return
        if (wake != null || listeningCommand || speaker.speaking) return
        val wait = pausedUntil - System.currentTimeMillis()
        if (wait > 0 || inCall()) {
            main.postDelayed({ startWake() }, if (wait > 0) wait else 5000L)
            return
        }
        try {
            val grammar = when (settings.wakeSensitivity) {
                "low" -> WAKE_GRAMMAR_LOW
                "high" -> WAKE_GRAMMAR_HIGH
                else -> WAKE_GRAMMAR
            }
            val rec = Recognizer(m, 16000f, grammar)
            wake = SpeechService(rec, 16000f).also { it.startListening(wakeListener) }
            Hub.voice.value = VoiceUi(VoicePhase.WAITING_WAKE)
        } catch (e: Exception) {
            Hub.voice.value = VoiceUi(VoicePhase.OFF, error = "Microfono occupato")
            main.postDelayed({ startWake() }, 8000L)
        }
    }

    private fun stopWake() {
        wake?.let {
            it.stop()
            it.shutdown()
        }
        wake = null
    }

    private val wakeListener = object : VoskListener {
        override fun onPartialResult(hypothesis: String?) = check(hypothesis, "partial")
        override fun onResult(hypothesis: String?) = check(hypothesis, "text")
        override fun onFinalResult(hypothesis: String?) = check(hypothesis, "text")
        override fun onError(exception: Exception?) {
            stopWake()
            main.postDelayed({ startWake() }, 3000L)
        }

        override fun onTimeout() {
            stopWake()
            startWake()
        }

        private fun check(json: String?, field: String) {
            val text = try { JSONObject(json ?: return).optString(field) } catch (e: Exception) { return }
            if (text.isNotBlank()) Hub.wakeHeard.value = text
            if (isWake(text, field == "partial")) main.post {
                Hub.wakeDetectedAt.value = System.currentTimeMillis()
                onWake()
            }
        }
    }

    /** Sensibilità: bassa vuole «ehi» + parola sulla frase finita, alta accetta anche varianti più lontane. */
    private fun isWake(text: String, partial: Boolean): Boolean {
        val t = text.lowercase()
        return when (settings.wakeSensitivity) {
            "low" -> !partial && Regex("(ehi|hey|hei) (tachi|tacchi|taxi|ta chi)").containsMatchIn(t)
            "high" -> (WAKE_WORDS + listOf("taki", "tacci", "tachy", "tazzi", "dacchi")).any { t.contains(it) }
            else -> WAKE_WORDS.any { t.contains(it) }
        }
    }

    private fun onWake() {
        if (listeningCommand) return
        stopWake()
        speaker.stop()
        speaker.beep(45)
        // lascia finire «…chi» prima di ascoltare il comando
        main.postDelayed({ listenCommand() }, 500)
    }

    // ---------------- comando ----------------

    private fun listenCommand() {
        listeningCommand = true
        Hub.voice.value = VoiceUi(VoicePhase.LISTENING)
        main.removeCallbacks(noSpeechTimeout)
        // Se non parla nessuno per ~5 secondi, chiude da solo l'ascolto
        main.postDelayed(noSpeechTimeout, NO_SPEECH_MS)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            val sr = recognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also { recognizer = it }
            sr.setRecognitionListener(androidListener)
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "it-IT")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, PAUSE_MS)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, PAUSE_MS)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1500L)
            sr.startListening(i)
        } else {
            listenFree()
        }
    }

    /** Riserva: riconoscimento completo con il modello sul telefono, se manca il servizio vocale di Google. */
    private fun listenFree() {
        val m = model ?: return endCommand()
        try {
            free = SpeechService(Recognizer(m, 16000f), 16000f).also {
                it.startListening(object : VoskListener {
                    override fun onPartialResult(hypothesis: String?) {
                        val p = try { JSONObject(hypothesis ?: "{}").optString("partial") } catch (e: Exception) { "" }
                        if (p.isNotBlank()) {
                            main.removeCallbacks(noSpeechTimeout)
                            Hub.voice.value = Hub.voice.value.copy(transcript = p)
                        }
                    }

                    override fun onResult(hypothesis: String?) {
                        val t = try { JSONObject(hypothesis ?: "{}").optString("text") } catch (e: Exception) { "" }
                        if (t.isNotBlank()) main.post {
                            main.removeCallbacks(noSpeechTimeout)
                            stopFree()
                            onCommandText(listOf(t))
                        }
                    }

                    override fun onFinalResult(hypothesis: String?) {}

                    override fun onError(exception: Exception?) {
                        main.post { main.removeCallbacks(noSpeechTimeout); stopFree(); endCommand() }
                    }

                    override fun onTimeout() {
                        main.post { main.removeCallbacks(noSpeechTimeout); stopFree(); endCommand() }
                    }
                }, 15000)
            }
        } catch (e: Exception) {
            endCommand()
        }
    }

    private fun stopFree() {
        free?.let { it.stop(); it.shutdown() }
        free = null
    }

    private val androidListener = object : AndroidRecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {
            main.removeCallbacks(noSpeechTimeout)
        }
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {
            main.removeCallbacks(noSpeechTimeout)
            Hub.voice.value = Hub.voice.value.copy(phase = VoicePhase.THINKING)
        }

        override fun onError(error: Int) {
            main.removeCallbacks(noSpeechTimeout)
            if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                val d = dialog
                if (d != null) {
                    listeningCommand = false
                    handleDialog(d, "")
                    return
                }
                endCommand()
            } else {
                // servizio di Google non disponibile: si usa il modello sul telefono
                listenFree()
            }
        }

        override fun onResults(results: Bundle?) {
            main.removeCallbacks(noSpeechTimeout)
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty().filter { it.isNotBlank() }
            if (list.isEmpty()) {
                val d = dialog
                if (d != null) { listeningCommand = false; handleDialog(d, "") } else endCommand()
            } else {
                onCommandText(list)
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!p.isNullOrBlank()) {
                main.removeCallbacks(noSpeechTimeout)
                Hub.voice.value = Hub.voice.value.copy(transcript = p)
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun endCommand() {
        main.removeCallbacks(noSpeechTimeout)
        listeningCommand = false
        main.postDelayed({ nextPendingMessage() }, 1200)
        if (!speaker.speaking) {
            Hub.voice.value = Hub.voice.value.copy(phase = VoicePhase.WAITING_WAKE)
        }
        main.postDelayed({ startWake() }, 300)
    }

    private fun say(text: String, then: (() -> Unit)? = null) {
        stopWake()
        Hub.voice.value = Hub.voice.value.copy(phase = VoicePhase.SPEAKING, answer = text)
        speaker.say(text) {
            then?.invoke()
            if (!listeningCommand) {
                Hub.voice.value = Hub.voice.value.copy(phase = VoicePhase.WAITING_WAKE)
                startWake()
            }
        }
    }

    /** Fa una domanda e ascolta subito la risposta, senza bisogno di ripetere «Ehi Tachi». */
    private fun ask(text: String) {
        stopWake()
        listeningCommand = true
        Hub.voice.value = Hub.voice.value.copy(phase = VoicePhase.SPEAKING, answer = text)
        speaker.say(text) { main.postDelayed({ listenCommand() }, 200) }
    }

    private fun onCommandText(texts: List<String>) {
        listeningCommand = false
        val text = texts.first()
        Hub.voice.value = Hub.voice.value.copy(phase = VoicePhase.THINKING, transcript = text)
        val d = dialog
        if (d == Dialog.Repeat) {
            dialog = null
            val cmd = bestCommand(texts)
            if (cmd is Command.Unknown) say("Non ho capito.") else execute(cmd)
            if (!speaker.speaking && !listeningCommand) endCommand()
            return
        }
        if (d != null) {
            // per le risposte sì o no prendo la prima trascrizione che lo dice chiaramente
            val pick = texts.firstOrNull { yesNo(it) != null } ?: text
            handleDialog(d, if (d.isYesNo()) pick else text)
            return
        }
        execute(bestCommand(texts))
        if (!speaker.speaking && !listeningCommand) endCommand()
    }

    private fun Dialog.isYesNo() = this is Dialog.AskRead || this is Dialog.AskReply || this is Dialog.AskAnswer ||
        this is Dialog.ReplyConfirm || this is Dialog.ComposeConfirm || this is Dialog.ConfirmRoute

    /** Google propone fino a tre trascrizioni: vince la prima che è un comando conosciuto. */
    private fun bestCommand(texts: List<String>): Command {
        val parsed = texts.map { CommandParser.parse(it) }
        return parsed.firstOrNull { it !is Command.Unknown && it !is Command.AskGemini }
            ?: parsed.firstOrNull { it is Command.AskGemini }
            ?: parsed.first()
    }

    private fun yesNo(text: String): Boolean? {
        val t = CommandParser.normalize(text).trim()
        if (t.isBlank()) return null
        return CommandParser.yesNo(text)
    }

    /** Ripete la domanda una volta se non ha capito, poi lascia perdere. */
    private fun retryOrDrop(d: Dialog, question: String, yesNoQuestion: Boolean = true) {
        if (dialogRetry < 1) {
            dialogRetry++
            dialog = d
            ask(if (yesNoQuestion) "Sì o no?" else question)
        } else {
            endDialog(null)
        }
    }

    /** Chiude la conversazione; senza testo basta un bip. */
    private fun endDialog(text: String?) {
        dialog = null
        dialogRetry = 0
        if (text == null) {
            speaker.beep(25)
            endCommand()
        } else {
            say(text) { main.postDelayed({ nextPendingMessage() }, 800) }
        }
    }

    private fun handleDialog(d: Dialog, text: String) {
        when (d) {
            is Dialog.AskRead -> when (yesNo(text)) {
                true -> {
                    dialogRetry = 0
                    dialog = Dialog.AskReply(d.msg)
                    ask("${d.msg.text}. Vuoi rispondere?")
                }
                false -> endDialog(null)
                null -> retryOrDrop(d, "Lo leggo?")
            }
            is Dialog.AskReply -> when (yesNo(text)) {
                true -> {
                    dialogRetry = 0
                    if (d.msg.replyIntent == null) {
                        endDialog("Da qui non posso rispondere a questo messaggio.")
                    } else {
                        dialog = Dialog.ReplyText(d.msg)
                        ask("Cosa rispondo?")
                    }
                }
                false -> {
                    Hub.removeMessage(d.msg.key)
                    endDialog(null)
                }
                null -> retryOrDrop(d, "Vuoi rispondere?")
            }
            is Dialog.ReplyText -> {
                if (text.isBlank()) {
                    retryOrDrop(d, "Cosa rispondo?", false)
                } else {
                    dialogRetry = 0
                    dialog = Dialog.ReplyConfirm(d.msg, text)
                    ask("Ho scritto: $text. Lo invio?")
                }
            }
            is Dialog.AskAnswer -> when (yesNo(text)) {
                true -> {
                    dialog = null
                    dialogRetry = 0
                    answerCall(true)
                }
                false -> {
                    dialog = null
                    dialogRetry = 0
                    answerCall(false)
                    say("Rifiutata.")
                }
                null -> if (Hub.incomingCall.value != null) retryOrDrop(d, "Rispondo?") else { dialog = null; endCommand() }
            }
            is Dialog.ReplyConfirm -> if (wantsChange(text)) {
                dialogRetry = 0
                dialog = Dialog.ReplyText(d.msg)
                ask("Cosa rispondo?")
            } else when (yesNo(text)) {
                true -> {
                    val ok = NotificationReader.reply(this, d.msg, d.text)
                    if (ok) Hub.removeMessage(d.msg.key)
                    endDialog(if (ok) "Inviato." else "Non riesco a rispondere da qui a questo messaggio.")
                }
                false -> endDialog("Non lo invio.")
                null -> retryOrDrop(d, "Lo invio?")
            }
            is Dialog.ComposeApp -> {
                val t = CommandParser.normalize(text)
                val app = when {
                    t.contains("whatsapp") || t.contains("whats app") || t.contains("uozap") -> "whatsapp"
                    t.contains("sms") || t.contains("messaggio") || t.contains("normale") || t.contains("esse emme esse") -> "sms"
                    else -> null
                }
                when {
                    app != null -> {
                        dialogRetry = 0
                        composeNext(d.to, app, d.text)
                    }
                    yesNo(text) == false -> endDialog(null)
                    else -> retryOrDrop(d, "Su WhatsApp o con SMS?", false)
                }
            }
            is Dialog.ComposeText -> {
                if (text.isBlank()) {
                    retryOrDrop(d, "Cosa scrivo?", false)
                } else if (CommandParser.normalize(text) in setOf("annulla", "lascia stare", "niente")) {
                    endDialog(null)
                } else {
                    dialogRetry = 0
                    composeNext(d.to, d.app, text)
                }
            }
            is Dialog.ComposeConfirm -> if (wantsChange(text)) {
                dialogRetry = 0
                dialog = Dialog.ComposeText(d.to, d.app)
                ask("Cosa scrivo?")
            } else when (yesNo(text)) {
                true -> {
                    dialog = null
                    dialogRetry = 0
                    deliver(d.to, d.app, d.text)
                }
                false -> endDialog("Non lo invio.")
                null -> retryOrDrop(d, "Lo invio?")
            }
            Dialog.Repeat -> endDialog(null)
            is Dialog.ComposeTo -> {
                if (text.isBlank() || isNo(text)) {
                    if (text.isBlank()) retryOrDrop(d, "A chi scrivo?", false) else endDialog(null)
                } else {
                    dialogRetry = 0
                    dialog = null
                    startCompose(Command.SendMessage(CommandParser.normalize(text).replace(Regex("^(a|ad|al|alla|per)\\s+"), ""), d.app))
                }
            }
            is Dialog.PickContact -> {
                val c = pickOption(text, d.options.map { it.name })?.let { d.options[it] }
                when {
                    c != null -> {
                        dialogRetry = 0
                        dialog = null
                        when (d.purpose) {
                            "call" -> callContact(c)
                            "wacall" -> whatsappCallContact(c)
                            else -> continueCompose(c, d.app, d.text)
                        }
                    }
                    isNo(text) -> endDialog(null)
                    else -> retryOrDrop(d, "Quale? " + d.options.joinToString(" o ") { it.name } + "?", false)
                }
            }
            is Dialog.AskPlace -> {
                if (text.isBlank()) retryOrDrop(d, "Dove ti porto?", false)
                else if (isNo(text)) endDialog(null)
                else {
                    dialogRetry = 0
                    dialog = null
                    val c = CommandParser.parse("portami a " + CommandParser.normalize(text).replace(Regex("^(a|al|alla|in|da|verso)\\s+"), ""))
                    execute(if (c is Command.Navigate) c.copy(waze = d.waze) else c)
                }
            }
            is Dialog.PickPlace -> {
                val i = pickOption(text, d.options.map { it.name })
                when {
                    i != null -> {
                        dialogRetry = 0
                        dialog = null
                        val p = d.options[i]
                        if (p.lat != null) proposeRoute(p, d.waze) else scope.launch {
                            val g = NavController.geocodePlace(this@VoiceService, listOf(p.name, p.address).filter { it.isNotBlank() }.joinToString(", "))
                                ?: NavController.geocodePlace(this@VoiceService, p.address)
                            if (g == null) say("Non riesco a trovare l'indirizzo di ${p.name}.")
                            else proposeRoute(p.copy(lat = g.lat, lng = g.lng, address = p.address.ifBlank { g.address }), d.waze)
                        }
                    }
                    isNo(text) -> endDialog(null)
                    else -> retryOrDrop(d, "Quale scegli? " + ordinalList(d.options.size) + "?", false)
                }
            }
            is Dialog.ConfirmRoute -> when (yesNo(text) ?: (if (Regex("^(partiamo|parti|vai|andiamo|avvia)").containsMatchIn(CommandParser.normalize(text))) true else null)) {
                true -> {
                    dialog = null
                    dialogRetry = 0
                    startRoute(d.place, d.waze)
                }
                false -> {
                    NavController.cancelPreview()
                    endDialog(null)
                }
                null -> if (dialogRetry < 1) retryOrDrop(d, "Partiamo?") else {
                    dialog = null
                    dialogRetry = 0
                    say(if (d.waze) "Lascio stare." else "Il percorso è pronto: di' partiamo quando vuoi.")
                }
            }
            is Dialog.PickRadio -> {
                val i = pickOption(text, d.options)
                when {
                    i != null -> {
                        dialog = null
                        dialogRetry = 0
                        playRadio(d.options[i])
                        endCommand()
                    }
                    isNo(text) -> endDialog(null)
                    text.isNotBlank() && dialogRetry >= 1 -> {
                        dialog = null
                        playRadio(CommandParser.normalize(text).removePrefix("radio ").trim())
                        endCommand()
                    }
                    else -> retryOrDrop(d, "Quale metto? " + ordinalList(d.options.size) + "?", false)
                }
            }
        }
    }

    private fun isNo(text: String) = text.isNotBlank() && yesNo(text) == false

    private fun ordinalList(n: Int) = listOf("la prima", "la seconda", "la terza", "la quarta").take(n).let {
        if (it.size <= 1) it.joinToString() else it.dropLast(1).joinToString(", ") + " o " + it.last()
    }

    /** Scelta tra opzioni lette a voce: «la seconda», «il primo», «tre», oppure il nome (anche detto a metà). */
    private fun pickOption(text: String, names: List<String>): Int? {
        val t = CommandParser.normalize(text)
        if (t.isBlank()) return null
        val ord = listOf(
            Regex("\\b(prim[oa]|uno|una|1)\\b"),
            Regex("\\b(second[oa]|due|2)\\b"),
            Regex("\\b(terz[oa]|tre|3)\\b"),
            Regex("\\b(quart[oa]|quattro|4)\\b"),
        )
        ord.forEachIndexed { i, r -> if (i < names.size && r.containsMatchIn(t)) return i }
        if (Regex("\\b(ultim[oa])\\b").containsMatchIn(t)) return names.lastIndex
        val words = normName(t).split(" ").filter { it.length >= 3 }
        var best = -1
        var bestScore = 0
        names.forEachIndexed { i, n ->
            val nw = normName(n).split(" ")
            val score = words.count { w -> nw.any { tokenMatch(w, it) } }
            if (score > bestScore) { bestScore = score; best = i }
        }
        return if (bestScore > 0) best else null
    }

    private fun wantsChange(text: String): Boolean =
        Regex("^(correggi|cambia|riscrivi|modifica|rifallo|ripeti)").containsMatchIn(CommandParser.normalize(text))

    private fun who(m: IncomingMessage): String =
        if (m.group != null) "${m.sender} nel gruppo ${m.group} su ${m.app}" else "${m.sender} su ${m.app}"

    /** Annuncia il messaggio e chiede se leggerlo. */
    private fun announce(m: IncomingMessage) {
        dialogRetry = 0
        dialog = Dialog.AskRead(m)
        ask("Messaggio da ${who(m)}. Lo leggo?")
    }

    /** Lettura richiesta da te: niente «lo leggo?», direttamente il testo. */
    private fun readNow(m: IncomingMessage, intro: String?) {
        dialogRetry = 0
        dialog = Dialog.AskReply(m)
        ask((intro?.let { "$it " } ?: "") + "Da ${who(m)}: ${m.text}. Vuoi rispondere?")
    }

    /** Passa al prossimo messaggio in coda, se non sei già impegnato con un altro. */
    private fun nextPendingMessage() {
        if (dialog != null || listeningCommand || speaker.speaking || Hub.incomingCall.value != null) return
        val (m, how) = pendingMessages.removeFirstOrNull() ?: return
        if (Hub.messages.value.none { it.key == m.key }) return nextPendingMessage()
        when (how) {
            NAME_ONLY -> say("Messaggio da ${who(m)}.") { main.postDelayed({ nextPendingMessage() }, 800) }
            READ_NOW -> readNow(m, null)
            else -> announce(m)
        }
    }

    private fun isFavorite(name: String): Boolean {
        val favs = settings.favorites.split(",").map { it.trim().lowercase() }.filter { it.isNotBlank() }
        val n = name.lowercase()
        return favs.any { n.contains(it) }
    }

    // ---------------- chiamate in arrivo ----------------

    private fun onIncomingCall(call: IncomingCall?) {
        if (call == null) {
            // ha già risposto o la chiamata è finita: smetto di chiedere
            if (dialog is Dialog.AskAnswer) {
                dialog = null
                dialogRetry = 0
                recognizer?.cancel()
                speaker.stop()
                listeningCommand = false
                main.postDelayed({ startWake() }, 1500)
            }
            return
        }
        Hub.lastCaller.value = call.caller
        if (!settings.announceCalls || settings.mode != "driver") return
        stopWake()
        recognizer?.cancel()
        speaker.stop()
        dialogRetry = 0
        dialog = Dialog.AskAnswer(call)
        ask("Chiamata da ${call.caller}. Rispondo?")
    }

    @Suppress("DEPRECATION")
    private fun answerCall(accept: Boolean) {
        if (!granted(Manifest.permission.ANSWER_PHONE_CALLS)) {
            say("Mi manca il permesso per rispondere alle chiamate.")
            return
        }
        try {
            val tm = getSystemService(android.telecom.TelecomManager::class.java)
            if (accept) tm?.acceptRingingCall() else tm?.endCall()
        } catch (e: SecurityException) {
        }
        listeningCommand = false
    }

    private fun bringToFront(screen: Screen? = null) {
        screen?.let { Hub.screen.value = it }
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
            )
        } catch (e: Exception) {
        }
    }

    private fun execute(cmd: Command) {
        when (cmd) {
            is Command.Navigate -> navigate(cmd)
            Command.BackToMaps -> {
                Hub.send(UiAction.BackToMaps)
                bringToFront(Screen.DASHBOARD)
                say("Torno a Google Maps.")
            }
            Command.StopNavigation -> {
                Hub.send(UiAction.StopNavigation)
                say("Navigazione terminata.")
            }
            is Command.PlayMusic -> {
                Radio.stop()
                val key = cmd.app ?: settings.musicApp
                val (label, pkg) = Apps.MUSIC[key] ?: Apps.MUSIC.getValue("spotify")
                if (!Apps.isInstalled(this, pkg)) {
                    say("$label non è installata.")
                } else {
                    Apps.playFromSearch(this, pkg, cmd.query)
                    pausedUntil = System.currentTimeMillis() + 1500
                    main.postDelayed({ bringToFront() }, 2500)
                }
            }
            is Command.PlayRadio -> playRadio(cmd.station)
            Command.NextRadio -> {
                val cur = Radio.current
                val idx = Radio.NATIONAL.indexOfFirst { it.equals(cur, true) }
                playRadio(Radio.NATIONAL[(idx + 1).mod(Radio.NATIONAL.size)])
            }
            Command.Pause -> if (Radio.isActive()) Radio.pause() else MediaSessions.pause(this)
            Command.Resume -> if (Hub.radio.value != null && !MediaSessions.hasSession()) Radio.resume() else MediaSessions.play(this)
            Command.Next -> MediaSessions.next(this)
            Command.Previous -> MediaSessions.previous(this)
            is Command.Volume -> MediaSessions.volume(this, cmd.up)
            Command.WhatIsPlaying -> whatIsPlaying()
            is Command.Call -> if (cmd.whatsapp) whatsappCall(cmd.name) else call(cmd.name)
            Command.CallBack -> {
                val who = Hub.lastCaller.value
                if (who == null || who == "numero sconosciuto") say("Non so chi richiamare.") else call(who)
            }
            Command.HangUp -> if (Hub.incomingCall.value != null || inCall()) answerCall(false) else say("Non c'è nessuna chiamata.")
            is Command.SendMessage -> startCompose(cmd)
            is Command.ReadMessages -> readMessages(cmd.app, cmd.onlyLast)
            is Command.SearchNearby -> searchNearby(cmd.query, cmd.best, false)
            Command.LocalRadio -> localRadio()
            Command.Go -> when {
                NavController.startPreview() -> speaker.beep(25)
                else -> say("Non c'è un percorso pronto. Dimmi dove andare.")
            }
            Command.Reply -> if (Hub.incomingCall.value != null) answerCall(true) else {
                val m = Hub.messages.value.lastOrNull { it.replyIntent != null }
                if (m == null) say("Non ci sono messaggi a cui rispondere.") else {
                    dialogRetry = 0
                    dialog = Dialog.ReplyText(m)
                    ask("Cosa rispondo a ${who(m)}?")
                }
            }
            Command.JoinMeeting -> joinMeeting()
            is Command.OpenApp -> openApp(cmd.name)
            is Command.SearchVideo -> {
                if (settings.mode != "passenger") {
                    say("I video si possono aprire solo in modalità passeggero.")
                } else if (!Apps.searchVideo(this, cmd.app, cmd.title)) {
                    say("Non trovo l'app ${cmd.app}.")
                }
            }
            is Command.SetMode -> {
                Hub.send(UiAction.SetMode(cmd.driver))
                bringToFront()
                say(if (cmd.driver) "Modalità guidatore." else "Modalità passeggero.")
            }
            Command.WhereIsCar -> whereIsCar()
            Command.FindFuel -> {
                bringToFront(Screen.FUEL)
                say("Ecco i distributori più economici.")
            }
            is Command.AddToBar -> editBar(cmd.app, add = true)
            is Command.RemoveFromBar -> editBar(cmd.app, add = false)
            Command.Dashboard -> bringToFront(Screen.DASHBOARD)
            Command.Settings -> bringToFront(Screen.SETTINGS)
            Command.Mute -> {
                alertsMuted = true
                say("Avvisi silenziati per questo viaggio.")
            }
            is Command.WeatherAt -> weatherAt(cmd.place)
            Command.Eta -> eta()
            Command.WhereAmI -> whereAmI()
            is Command.Avoid -> avoid(cmd)
            Command.FindParking -> findParking()
            Command.SaveParking -> {
                val loc = Hub.location.value
                if (loc == null) say("Non ho ancora la tua posizione.") else {
                    scope.launch { Car.saveParking(applicationContext, loc) }
                    say("Parcheggio salvato.")
                }
            }
            is Command.Reminder -> {
                if (cmd.minutes <= 10) {
                    say("Ti avviso dieci minuti prima della scadenza, quindi dimmi un tempo più lungo di dieci minuti.")
                } else {
                    Car.setReminder(applicationContext, cmd.minutes)
                    say("Ti avviso dieci minuti prima della scadenza.")
                }
            }
            Command.CameraAhead -> {
                val c = Hub.camera.value
                when {
                    !settings.cameras -> say("Gli avvisi degli autovelox sono spenti.")
                    c == null -> say("Nessun autovelox nei prossimi ${settings.cameraWarnMeters} metri.")
                    else -> say("${c.label} tra ${c.distanceM} metri" + (c.maxSpeed?.let { ", limite $it" } ?: "") + ".")
                }
            }
            is Command.SetPref -> setPref(cmd.key, cmd.value)
            Command.Time -> say("Sono le " + java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("H:mm")) + ".")
            Command.Battery -> battery()
            Command.Cancel -> speaker.beep(25)
            Command.CloseApp -> say("Chiudo Tachimetro.") { Hub.send(UiAction.Close) }
            is Command.AskGemini -> askGemini(cmd.question)
            is Command.Unknown -> {
                dialogRetry = 0
                dialog = Dialog.Repeat
                ask("Non ho capito, ripeti.")
            }
        }
    }

    private fun navigate(cmd: Command.Navigate) {
        if (cmd.place.isBlank()) {
            dialogRetry = 0
            dialog = Dialog.AskPlace(cmd.waze)
            return ask("Dove ti porto?")
        }
        when (cmd.place) {
            "@macchina" -> return whereIsCar()
            "@distributore" -> {
                val cached = Hub.fuel.value.firstOrNull()
                if (cached != null) {
                    proposeRoute(Place(cached.name, cached.address, cached.lat, cached.lng), cmd.waze)
                    return
                }
                val here = Hub.location.value ?: return say("Non ho ancora la tua posizione.")
                Hub.voice.value = Hub.voice.value.copy(phase = VoicePhase.THINKING)
                scope.launch {
                    try {
                        val list = Fuel.nearby(here, settings.fuelType)
                        Hub.fuel.value = list
                        val f = list.firstOrNull()
                        if (f == null) say("Non trovo distributori entro 10 chilometri.")
                        else proposeRoute(Place(f.name, f.address, f.lat, f.lng, String.format(java.util.Locale.ITALIAN, "%.3f euro", f.price)), cmd.waze)
                    } catch (e: Exception) {
                        say("Prezzi dei carburanti non raggiungibili in questo momento.")
                    }
                }
                return
            }
            "@appuntamento" -> {
                val loc = nextAppointmentPlace() ?: return say("Non trovo appuntamenti con un indirizzo nelle prossime ore.")
                return findAndPropose(loc, "il prossimo appuntamento", cmd.waze)
            }
        }
        val place = when (cmd.place) {
            "@casa" -> settings.home.ifBlank { return say("Non hai ancora impostato l'indirizzo di casa.") }
            "@lavoro" -> settings.work.ifBlank { return say("Non hai ancora impostato l'indirizzo del lavoro.") }
            else -> cmd.place
        }
        val nice = when (cmd.place) {
            "@casa" -> "Casa"
            "@lavoro" -> "Lavoro"
            else -> null
        }
        // «ufficio postale in via Marmorata»: un tipo di posto vicino a un indirizzo
        if (nice == null && Places.isCategory(place)) return findPoi(place, cmd.waze)
        findAndPropose(place, nice, cmd.waze)
    }

    /** Cerca un indirizzo e propone il percorso. */
    private fun findAndPropose(query: String, nice: String?, waze: Boolean) {
        Hub.voice.value = Hub.voice.value.copy(phase = VoicePhase.THINKING)
        scope.launch {
            val g = NavController.geocodePlace(this@VoiceService, query)
            if (g == null) {
                say("Non trovo $query.")
            } else {
                proposeRoute(if (nice != null) g.copy(name = nice) else g, waze)
            }
        }
    }

    /** Un tipo di posto, eventualmente vicino a una via: «ufficio postale in via Marmorata», «farmacia a Trastevere». */
    private fun findPoi(query: String, waze: Boolean) {
        val split = Regex("^(.+?)\\s+(in|a|ad|di|vicino a|vicino al|vicino alla|presso|dalle parti di|zona)\\s+(.+)$").find(query)
        val what = split?.groupValues?.get(1) ?: query
        val near = split?.groupValues?.get(3)
        Hub.voice.value = Hub.voice.value.copy(phase = VoicePhase.THINKING)
        scope.launch {
            try {
                val center = if (near != null) NavController.geocodePlace(this@VoiceService, near) else null
                val lat = center?.lat ?: Hub.location.value?.latitude ?: return@launch say("Non ho ancora la tua posizione.")
                val lng = center?.lng ?: Hub.location.value?.longitude ?: return@launch say("Non ho ancora la tua posizione.")
                var found = Places.filterFor(what)?.let { Places.nearest(it, lat, lng, 1) }.orEmpty()
                if (found.isEmpty() && settings.geminiKey.isNotBlank() && !Gemini.searchUnavailable) {
                    found = try {
                        Gemini.places(settings.geminiKey, query, false, lat, lng, null).take(1)
                    } catch (e: Gemini.GeminiException) {
                        Hub.geminiError.value = e.detail
                        emptyList()
                    }
                }
                val p = found.firstOrNull()
                if (p == null) {
                    // non trovo il posto: almeno l'indirizzo
                    if (center != null) proposeRoute(center, waze) else say("Non trovo $query.")
                } else if (p.lat == null) {
                    val g = NavController.geocodePlace(this@VoiceService, listOf(p.name, p.address).joinToString(", "))
                    if (g == null) say("Non trovo $query.") else proposeRoute(p.copy(lat = g.lat, lng = g.lng), waze)
                } else {
                    proposeRoute(p, waze)
                }
            } catch (e: Exception) {
                say("Non riesco a cercare $query in questo momento.")
            }
        }
    }

    /** Mostra il percorso sulla mappa e chiede se partire. */
    private fun proposeRoute(p: Place, waze: Boolean) {
        val lat = p.lat ?: return say("Non trovo ${p.name}.")
        val lng = p.lng ?: return say("Non trovo ${p.name}.")
        val label = listOf(p.name, p.address).filter { it.isNotBlank() }.distinct().joinToString(", ")
        dialogRetry = 0
        if (waze) {
            dialog = Dialog.ConfirmRoute(p, true)
            return ask("$label. Parto con Waze?")
        }
        bringToFront(Screen.DASHBOARD)
        val ready = NavController.preview(lat, lng, p.name) { r ->
            main.post {
                when {
                    r == null -> say("Non trovo un percorso per $label.")
                    r.first == 0 -> {
                        dialog = Dialog.ConfirmRoute(p, false)
                        ask("$label. Partiamo?")
                    }
                    else -> {
                        dialog = Dialog.ConfirmRoute(p, false)
                        ask("$label: ${durationWords(r.first)}, ${Places.spokenDistance(r.second)}. Partiamo?")
                    }
                }
            }
        }
        if (!ready) {
            dialog = Dialog.ConfirmRoute(p, false)
            ask("$label. Partiamo?")
        }
    }

    private fun durationWords(min: Int): String = when {
        min < 60 -> if (min == 1) "un minuto" else "$min minuti"
        min % 60 == 0 -> if (min == 60) "un'ora" else "${min / 60} ore"
        else -> (if (min / 60 == 1) "un'ora" else "${min / 60} ore") + " e ${min % 60} minuti"
    }

    private fun startRoute(p: Place, waze: Boolean) {
        val lat = p.lat ?: return
        val lng = p.lng ?: return
        if (waze) {
            NavController.cancelPreview()
            NavController.openWaze(this, null, lat, lng, p.name)
        } else if (!NavController.startPreview()) {
            NavController.go(this, lat, lng, p.name)
        }
        speaker.beep(25)
        endCommand()
    }

    // ---------------- ricerca di posti vicini ----------------

    private fun searchNearby(query: String, best: Boolean, waze: Boolean) {
        val loc = Hub.location.value ?: return say("Non ho ancora la tua posizione.")
        say("Cerco.")
        scope.launch {
            var list: List<Place> = emptyList()
            var fromGoogle = false
            val key = settings.geminiKey
            if (key.isNotBlank() && !Gemini.searchUnavailable) {
                try {
                    list = Gemini.places(key, query, best, loc.latitude, loc.longitude, townOf(loc))
                    fromGoogle = list.isNotEmpty()
                } catch (e: Gemini.GeminiException) {
                    Hub.geminiError.value = e.detail
                } catch (e: Exception) {
                }
            }
            if (list.isEmpty()) {
                list = try {
                    Places.nearest(Places.filterFor(query) ?: Places.nameFilter(query), loc.latitude, loc.longitude)
                } catch (e: Exception) {
                    emptyList()
                }
            }
            if (list.isEmpty()) return@launch say("Non trovo $query qui vicino.")
            if (list.size == 1) {
                proposeRoute(list.first(), waze)
                return@launch
            }
            val intro = if (best && !fromGoogle) "Senza recensioni a disposizione, ecco i più vicini. " else ""
            val names = listOf("Primo", "Secondo", "Terzo")
            val body = list.mapIndexed { i, p ->
                val parts = listOfNotNull(
                    p.name,
                    p.address.ifBlank { null },
                    p.distanceM?.let { Places.spokenDistance(it) },
                    p.note,
                )
                "${names[i]}: ${parts.joinToString(", ")}."
            }.joinToString(" ")
            dialogRetry = 0
            dialog = Dialog.PickPlace(list, waze)
            ask("$intro$body Quale scegli?")
        }
    }

    private suspend fun townOf(loc: Location): String? = withContext(Dispatchers.IO) {
        try {
            @Suppress("DEPRECATION")
            android.location.Geocoder(this@VoiceService, java.util.Locale.ITALY).getFromLocation(loc.latitude, loc.longitude, 1)
                ?.firstOrNull()?.let { a -> listOfNotNull(a.subLocality, a.locality).joinToString(", ").ifBlank { null } }
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun regionOf(loc: Location): String? = withContext(Dispatchers.IO) {
        try {
            @Suppress("DEPRECATION")
            android.location.Geocoder(this@VoiceService, java.util.Locale.ITALY).getFromLocation(loc.latitude, loc.longitude, 1)?.firstOrNull()?.adminArea
        } catch (e: Exception) {
            null
        }
    }

    /** «radio locali»: le stazioni più ascoltate della regione in cui sei, e scegli tu. */
    private fun localRadio() {
        scope.launch {
            val loc = Hub.location.value
            val region = settings.radioRegion.ifBlank { loc?.let { regionOf(it) }.orEmpty() }
            if (region.isBlank()) return@launch say("Non so ancora in che regione sei.")
            val list = try { Radio.regional(region).take(3) } catch (e: Exception) { emptyList() }
            if (list.isEmpty()) return@launch say("Non trovo radio locali per $region.")
            dialogRetry = 0
            dialog = Dialog.PickRadio(list)
            ask("Radio locali: ${list.dropLast(1).joinToString(", ")}${if (list.size > 1) " e " else ""}${list.last()}. Quale metto?")
        }
    }

    private fun playRadio(spoken: String) {
        val name = if (spoken.isBlank()) (Radio.current ?: Radio.NATIONAL.first()) else (Radio.match(spoken) ?: spoken)
        scope.launch {
            try {
                val st = Radio.resolve(name)
                if (st == null) {
                    say("Non trovo la radio $name.")
                } else {
                    MediaSessions.pause(this@VoiceService)
                    Radio.play(this@VoiceService, st)
                }
            } catch (e: Exception) {
                say("La radio non è raggiungibile in questo momento.")
            }
        }
    }

    private fun call(name: String) {
        if (!granted(Manifest.permission.READ_CONTACTS) || !granted(Manifest.permission.CALL_PHONE)) {
            return say("Per chiamare servono i permessi per contatti e telefono, nelle impostazioni.")
        }
        val digits = name.replace(Regex("[\\s./-]"), "")
        if (Regex("^\\+?\\d{5,}$").matches(digits)) return callContact(Contact(name, digits))
        val (found, _) = resolveContact(name.split(" ").filter { it.isNotBlank() })
        when {
            found.isEmpty() -> say("Non trovo $name tra i contatti.")
            found.size == 1 -> callContact(found.first())
            else -> askWhich(found, "call", null, "")
        }
    }

    private fun callContact(c: Contact) {
        Hub.lastCaller.value = c.name
        say("Chiamo ${c.name}.") {
            try {
                startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + c.number)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
            }
        }
    }

    private fun askWhich(options: List<Contact>, purpose: String, app: String?, text: String) {
        dialogRetry = 0
        dialog = Dialog.PickContact(options, purpose, app, text)
        ask(options.joinToString(" o ") { it.name } + "?")
    }

    // ---------------- rubrica: nomi capiti a voce ----------------

    private var contactCache: List<Contact>? = null
    private var contactCacheAt = 0L

    /** Tutti i contatti con un numero, uno per nome (preferendo il cellulare o il numero principale). */
    private fun allContacts(): List<Contact> {
        val now = System.currentTimeMillis()
        contactCache?.let { if (now - contactCacheAt < 10 * 60_000L) return it }
        val out = LinkedHashMap<String, Pair<Contact, Int>>()
        try {
            contentResolver.query(
                P.CONTENT_URI,
                arrayOf(P.CONTACT_ID, P.DISPLAY_NAME, P.NUMBER, P.IS_PRIMARY, P.TYPE),
                null, null, null,
            )?.use { c ->
                while (c.moveToNext()) {
                    val cid = c.getLong(0)
                    val name = c.getString(1)?.trim().orEmpty()
                    val num = c.getString(2)?.trim().orEmpty()
                    if (name.isBlank() || num.isBlank()) continue
                    val rank = (if (c.getInt(3) != 0) 2 else 0) + (if (c.getInt(4) == P.TYPE_MOBILE) 1 else 0)
                    val cur = out[name]
                    if (cur == null || rank > cur.second) out[name] = Contact(name, num, cid) to rank
                }
            }
        } catch (e: Exception) {
        }
        return out.values.map { it.first }.also {
            contactCache = it
            contactCacheAt = now
        }
    }

    /** Nome semplificato per il confronto: senza accenti e simboli, con C e K, doppie e H trattate allo stesso modo. */
    private fun normName(s: String): String = java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .replace("k", "c").replace("y", "i").replace("j", "i").replace("w", "v").replace("h", "")
        .replace(Regex("[^a-z0-9 ]"), " ")
        .replace(Regex("(.)\\1+"), "$1")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun tokenMatch(a: String, b: String): Boolean {
        if (a == b) return true
        if (a.length >= 4 && b.length >= 4 && distance(a, b) <= 1) return true
        // nome detto a metà, per esempio «Ale» per «Alessandro»
        return a.length >= 3 && b.startsWith(a) && b.length - a.length <= 4
    }

    private fun distance(a: String, b: String): Int {
        if (kotlin.math.abs(a.length - b.length) > 1) return 2
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]
            d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    /** Contatti in cui compaiono tutte le parole dette, i più somiglianti per primi. */
    private fun matchContacts(spoken: String): List<Contact> {
        val q = normName(spoken).split(" ").filter { it.isNotBlank() }
        if (q.isEmpty()) return emptyList()
        val scored = allContacts().mapNotNull { c ->
            val ct = normName(c.name).split(" ").filter { it.isNotBlank() }
            if (ct.isEmpty()) return@mapNotNull null
            if (!q.all { w -> ct.any { tokenMatch(w, it) } }) return@mapNotNull null
            val exact = q.count { w -> ct.any { it == w } }
            c to (exact * 10 + q.size * 10 - (ct.size - q.size).coerceAtLeast(0) * 3)
        }.sortedByDescending { it.second }
        if (scored.isEmpty()) return emptyList()
        val top = scored.first().second
        return scored.filter { it.second == top }.map { it.first }.take(3)
    }

    /** Cerca il nome più lungo all'inizio della frase: restituisce i contatti trovati e quante parole erano il nome. */
    private fun resolveContact(words: List<String>): Pair<List<Contact>, Int> {
        for (n in minOf(4, words.size) downTo 1) {
            val found = matchContacts(words.take(n).joinToString(" "))
            if (found.isNotEmpty()) return found to n
        }
        return emptyList<Contact>() to 0
    }

    // ---------------- messaggi dettati ----------------

    /** «scrivi a Marco che arrivo tra dieci minuti»: trova il contatto e chiede quello che manca. */
    private fun startCompose(cmd: Command.SendMessage) {
        if (!granted(Manifest.permission.READ_CONTACTS)) return say("Per scrivere ai contatti serve il permesso per i contatti, nelle impostazioni.")
        val words = cmd.rest.split(" ").filter { it.isNotBlank() }
        if (words.isEmpty()) {
            dialogRetry = 0
            dialog = Dialog.ComposeTo(cmd.app)
            return ask("A chi scrivo?")
        }
        val (found, used) = resolveContact(words)
        if (found.isEmpty()) return say("Non trovo ${words.take(2).joinToString(" ")} tra i contatti.")
        val text = words.drop(used).joinToString(" ")
            .replace(Regex("^(che|dicendo che|dicendogli che|dicendole che|dicendo|di|e digli che|e dille che|e scrivi|scrivendo|con scritto|il messaggio)\\s+"), "")
            .trim()
        if (found.size > 1) return askWhich(found, "msg", cmd.app, text)
        continueCompose(found.first(), cmd.app, text)
    }

    private fun continueCompose(to: Contact, appSaid: String?, text: String) {
        // l'app: quella detta, altrimenti quella dell'ultimo messaggio ricevuto da questa persona, altrimenti quella preferita
        val recent = Hub.messages.value.lastOrNull { it.group == null && sameName(it.sender, to.name) }
        val app = appSaid ?: recent?.app?.lowercase() ?: settings.msgApp
        dialogRetry = 0
        if (app == "ask") {
            dialog = Dialog.ComposeApp(to, text)
            ask("Su WhatsApp o con SMS?")
        } else {
            composeNext(to, app, text)
        }
    }

    private fun composeNext(to: Contact, app: String, text: String) {
        if (text.isBlank()) {
            dialog = Dialog.ComposeText(to, app)
            ask("Cosa scrivo a ${to.name}?")
        } else {
            dialog = Dialog.ComposeConfirm(to, app, text)
            ask("Scrivo a ${to.name} ${appWords(app)}: $text. Lo invio?")
        }
    }

    private fun appWords(app: String) = when (app) {
        "sms" -> "con un SMS"
        "teams" -> "su Teams"
        else -> "su WhatsApp"
    }

    private fun sameName(a: String, b: String): Boolean {
        val x = a.lowercase().trim()
        val y = b.lowercase().trim()
        return x == y || x.startsWith(y) || y.startsWith(x)
    }

    /** Invia davvero, dopo che hai confermato a voce. */
    private fun deliver(to: Contact, app: String, text: String) {
        val label = when (app) { "sms" -> "SMS"; "teams" -> "Teams"; else -> "WhatsApp" }
        // se c'è una notifica recente di questa persona, rispondo da lì senza aprire nulla
        val notif = Hub.messages.value.lastOrNull {
            it.app == label && it.group == null && it.replyIntent != null && sameName(it.sender, to.name)
        }
        if (notif != null && NotificationReader.reply(this, notif, text)) {
            Hub.removeMessage(notif.key)
            return endDialog("Inviato.")
        }
        when (app) {
            "sms" -> {
                if (!granted(Manifest.permission.SEND_SMS)) return endDialog("Per inviare SMS serve il permesso, nelle impostazioni.")
                try {
                    val sms = getSystemService(android.telephony.SmsManager::class.java)
                    sms.sendMultipartTextMessage(to.number, null, sms.divideMessage(text), null, null)
                    endDialog("SMS inviato a ${to.name}.")
                } catch (e: Exception) {
                    endDialog("Non sono riuscito a inviare l'SMS.")
                }
            }
            "teams" -> {
                Apps.findByName(this, "Teams")?.let { Apps.launch(this, it.packageName) }
                endDialog("Su Teams posso rispondere solo ai messaggi che ti arrivano. Ho aperto Teams.")
            }
            else -> {
                val auto = settings.waAutoSend && WhatsAppSender.isEnabled(this)
                val phone = waNumber(to.number)
                dialog = null
                dialogRetry = 0
                if (auto) {
                    speaker.beep(25)
                    if (!WhatsAppSender.open(this, phone, text, true)) {
                        say("WhatsApp non è installato.")
                    } else {
                        main.postDelayed({
                            if (!WhatsAppSender.lastResult) {
                                bringToFront()
                                say("Non sono riuscito a premere Invia. Il messaggio è pronto nella chat di WhatsApp.")
                            } else {
                                say("Inviato.")
                            }
                        }, 11_000)
                    }
                    endCommand()
                } else {
                    say("Ho preparato il messaggio nella chat di WhatsApp: tocca Invia.") {
                        if (!WhatsAppSender.open(this, phone, text, false)) say("WhatsApp non è installato.")
                    }
                }
            }
        }
    }

    /** Numero nel formato che serve a WhatsApp: prefisso internazionale senza «+». */
    private fun waNumber(raw: String): String {
        var n = raw.replace(Regex("[^+\\d]"), "")
        n = when {
            n.startsWith("+") -> n.drop(1)
            n.startsWith("00") -> n.drop(2)
            else -> "39$n"
        }
        return n
    }

    private fun whatsappCall(name: String) {
        if (!granted(Manifest.permission.READ_CONTACTS)) return say("Per chiamare serve il permesso per i contatti, nelle impostazioni.")
        val (found, _) = resolveContact(name.split(" ").filter { it.isNotBlank() })
        when {
            found.isEmpty() -> say("Non trovo $name tra i contatti.")
            found.size == 1 -> whatsappCallContact(found.first())
            else -> askWhich(found, "wacall", null, "")
        }
    }

    private fun whatsappCallContact(c: Contact) {
        val mime = "vnd.android.cursor.item/vnd.com.whatsapp.voip.call"
        val id = try {
            var foundId: Long? = null
            if (c.id >= 0L) {
                contentResolver.query(
                    ContactsContract.Data.CONTENT_URI,
                    arrayOf(ContactsContract.Data._ID),
                    ContactsContract.Data.MIMETYPE + " = ? AND " + ContactsContract.Data.CONTACT_ID + " = ?",
                    arrayOf(mime, c.id.toString()),
                    null,
                )?.use { cur -> if (cur.moveToFirst()) foundId = cur.getLong(0) }
            }
            if (foundId == null) {
                contentResolver.query(
                    ContactsContract.Data.CONTENT_URI,
                    arrayOf(ContactsContract.Data._ID),
                    ContactsContract.Data.MIMETYPE + " = ? AND " + ContactsContract.Data.DISPLAY_NAME + " = ?",
                    arrayOf(mime, c.name),
                    null,
                )?.use { cur -> if (cur.moveToFirst()) foundId = cur.getLong(0) }
            }
            foundId
        } catch (e: Exception) {
            null
        } ?: return say("${c.name} non risulta su WhatsApp.")
        Hub.lastCaller.value = c.name
        say("Chiamo ${c.name} su WhatsApp.") {
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW)
                        .setDataAndType(Uri.withAppendedPath(ContactsContract.Data.CONTENT_URI, id.toString()), mime)
                        .setPackage("com.whatsapp")
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            } catch (e: Exception) {
                say("WhatsApp non riesce ad avviare la chiamata.")
            }
        }
    }

    // ---------------- viaggio e informazioni ----------------

    private fun eta() {
        val n = Hub.nav.value
        when {
            !n.active -> say("Non stai navigando.")
            n.viaWaze -> say("Stai usando Waze: l'orario di arrivo lo trovi lì.")
            n.etaText.isBlank() -> say("Sto ancora calcolando l'arrivo.")
            else -> {
                val rest = n.remainingText.replace(" min · ", " minuti e ").replace(" km", " chilometri")
                say("Arrivi alle ${n.etaText}. Mancano $rest.")
            }
        }
    }

    private fun whereAmI() {
        val loc = Hub.location.value ?: return say("Non ho ancora la tua posizione.")
        scope.launch {
            val a = withContext(Dispatchers.IO) {
                try {
                    @Suppress("DEPRECATION")
                    android.location.Geocoder(this@VoiceService, java.util.Locale.ITALY).getFromLocation(loc.latitude, loc.longitude, 1)?.firstOrNull()
                } catch (e: Exception) {
                    null
                }
            }
            if (a == null) return@launch say("Non riesco a capire l'indirizzo in questo momento.")
            val street = listOfNotNull(a.thoroughfare, a.subThoroughfare).joinToString(" ")
            val town = a.locality ?: a.subAdminArea
            say(
                when {
                    street.isNotBlank() && town != null -> "Sei in $street, a $town."
                    town != null -> "Sei a $town."
                    else -> "Sei in ${a.getAddressLine(0)}."
                },
            )
        }
    }

    private fun whatIsPlaying() {
        val r = Hub.radio.value
        val np = Hub.nowPlaying.value
        when {
            r != null && r.isPlaying -> say("Stai ascoltando ${r.name}.")
            np != null && np.isPlaying -> {
                val by = if (np.artist.isNotBlank()) " di ${np.artist}" else ""
                say("${np.title}$by.")
            }
            else -> say("Non c'è musica o radio in riproduzione.")
        }
    }

    private fun avoid(cmd: Command.Avoid) {
        if (cmd.highways) NavController.avoidHighways = cmd.enable
        if (cmd.tolls) NavController.avoidTolls = cmd.enable
        val what = listOfNotNull(if (cmd.highways) "autostrade" else null, if (cmd.tolls) "pedaggi" else null).joinToString(" e ")
        val action = if (cmd.enable) "evito $what" else "includo $what"
        val rerouteMsg = if (cmd.enable) "Ricalcolo il percorso senza $what." else "Ricalcolo il percorso includendo $what."
        if (NavController.reroute(this)) say(rerouteMsg) else say("Nei prossimi percorsi $action fino alla chiusura.")
    }

    private fun findParking() {
        val n = Hub.nav.value
        val here = Hub.location.value
        val (lat, lng, nearDest) = when {
            n.active && n.destLat != null && n.destLng != null -> Triple(n.destLat, n.destLng, true)
            here != null -> Triple(here.latitude, here.longitude, false)
            else -> return say("Non ho ancora la tua posizione.")
        }
        say(if (nearDest) "Cerco un parcheggio vicino alla destinazione." else "Cerco un parcheggio qui vicino.")
        scope.launch {
            try {
                val q = String.format(
                    java.util.Locale.US,
                    "[out:json][timeout:15];nwr(around:800,%.5f,%.5f)[amenity=parking][access!~\"private|customers\"];out center 30;",
                    lat, lng,
                )
                val els = Net.getJsonObject("https://overpass-api.de/api/interpreter?data=" + Net.enc(q)).getJSONArray("elements")
                var best: Triple<Double, Double, String>? = null
                var bestD = Float.MAX_VALUE
                for (i in 0 until els.length()) {
                    val e = els.getJSONObject(i)
                    val c = e.optJSONObject("center")
                    val plat = c?.optDouble("lat") ?: e.optDouble("lat", Double.NaN)
                    val plng = c?.optDouble("lon") ?: e.optDouble("lon", Double.NaN)
                    if (plat.isNaN() || plng.isNaN()) continue
                    val d = FloatArray(1)
                    Location.distanceBetween(lat, lng, plat, plng, d)
                    if (d[0] < bestD) {
                        bestD = d[0]
                        val name = e.optJSONObject("tags")?.optString("name").orEmpty().ifBlank { "Parcheggio" }
                        best = Triple(plat, plng, name)
                    }
                }
                val b = best
                if (b == null) {
                    say("Non trovo parcheggi pubblici entro 800 metri.")
                } else {
                    Hub.send(UiAction.NavigateCoords(b.first, b.second, b.third, false))
                    bringToFront(Screen.DASHBOARD)
                    val where = if (nearDest) "dalla destinazione" else "da qui"
                    say("${b.third} a ${(bestD / 10).toInt() * 10} metri $where. Ti ci porto.")
                }
            } catch (e: Exception) {
                say("Non riesco a cercare i parcheggi in questo momento.")
            }
        }
    }

    private fun setPref(key: String, value: String) {
        val on = value == "true"
        scope.launch {
            Prefs.edit(applicationContext) {
                when (key) {
                    "dnd" -> it[Keys.dnd] = on
                    "fullScreen" -> it[Keys.fullScreen] = on
                    "readMessages" -> it[Keys.readMessages] = on
                    "cameras" -> it[Keys.cameras] = on
                    "themeMode" -> it[Keys.themeMode] = value
                    "wakeSensitivity" -> it[Keys.wakeSensitivity] = value
                }
            }
        }
        when (key) {
            "dnd" -> {
                if (on) {
                    if (!Dnd.hasAccess(this)) return say("Per il non disturbare serve un permesso: lo trovi nelle impostazioni, sezione Auto.")
                    Dnd.enable(this)
                } else {
                    Dnd.restore(this)
                }
                say(if (on) "Non disturbare attivato." else "Non disturbare disattivato.")
            }
            "fullScreen" -> say(if (on) "Schermo intero attivato." else "Schermo intero disattivato.")
            "readMessages" -> say(if (on) "Ti leggerò i messaggi." else "Non ti leggerò più i messaggi.")
            "cameras" -> say(if (on) "Avvisi autovelox attivati." else "Avvisi autovelox disattivati.")
            "themeMode" -> say(when (value) { "night" -> "Tema notte."; "day" -> "Tema giorno."; else -> "Tema automatico." })
            "wakeSensitivity" -> {
                say(when (value) { "high" -> "Sensibilità alta."; "low" -> "Sensibilità bassa."; else -> "Sensibilità normale." }) {
                    stopWake()
                    main.postDelayed({ startWake() }, 500)
                }
            }
        }
    }

    private fun weatherAt(place: String?) {
        scope.launch {
            try {
                val (lat, lng, label) = when (place) {
                    null -> {
                        val loc = Hub.location.value
                        if (loc == null) {
                            val w = Hub.weather.value ?: return@launch say("Non ho ancora la tua posizione.")
                            return@launch say("${w.description}, ${w.tempC.toInt()} gradi.")
                        }
                        Triple(loc.latitude, loc.longitude, null)
                    }
                    "@arrivo" -> {
                        val n = Hub.nav.value
                        if (!n.active || n.destLat == null || n.destLng == null) return@launch say("Non stai navigando verso una destinazione.")
                        Triple(n.destLat, n.destLng, "All'arrivo")
                    }
                    else -> {
                        val g = NavController.geocode(this@VoiceService, place) ?: return@launch say("Non trovo $place.")
                        Triple(g.first, g.second, "A $place")
                    }
                }
                val w = Weather.fetch(lat, lng)
                if (place == null) Hub.weather.value = w
                say((if (label != null) "$label: " else "") + "${w.description.lowercase().replaceFirstChar { it.uppercase() }}, ${w.tempC.toInt()} gradi.")
            } catch (e: Exception) {
                say("Il meteo non è raggiungibile in questo momento.")
            }
        }
    }

    private fun battery() {
        val h = Hub.health.value
        val pct = if (h.batteryPct >= 0) h.batteryPct else
            (getSystemService(android.os.BatteryManager::class.java)?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1)
        if (pct < 0) return say("Non riesco a leggere la batteria.")
        val extra = buildString {
            if (h.charging) append(", in carica")
            if (h.hot) append(". Attenzione, il telefono è caldo")
        }
        say("Batteria al $pct per cento$extra.")
    }

    private fun readMessages(app: String?, onlyLast: Boolean) {
        val all = Hub.messages.value.filter { app == null || it.app == app }
        val where = app?.let { " su $it" } ?: ""
        if (all.isEmpty()) {
            return say(if (NotificationReader.connected) "Nessun messaggio nuovo$where." else "Per leggere i messaggi attiva la lettura delle notifiche nelle impostazioni.")
        }
        val list = if (onlyLast) listOf(all.last()) else all
        pendingMessages.clear()
        list.drop(1).forEach { pendingMessages.addLast(it to READ_NOW) }
        val intro = if (list.size > 1) "${numberWord(list.size)} messaggi$where." else null
        readNow(list.first(), intro)
    }

    private fun numberWord(n: Int) = when (n) {
        2 -> "Due"; 3 -> "Tre"; 4 -> "Quattro"; 5 -> "Cinque"; else -> n.toString()
    }

    private fun onMessages(list: List<IncomingMessage>) {
        for (m in list) {
            if (!announced.add(m.key)) continue
            if (!settings.readMessages || settings.mode != "driver") continue
            if (System.currentTimeMillis() - m.time > 120_000) continue
            val fav = isFavorite(m.sender)
            if (m.group != null && !fav) {
                when (settings.groupMode) {
                    "never" -> continue
                    "name" -> {
                        pendingMessages.addLast(m to NAME_ONLY)
                        continue
                    }
                }
            }
            pendingMessages.addLast(m to ANNOUNCE)
        }
        if (announced.size > 300) announced.clear()
        nextPendingMessage()
    }

    private fun calendarEvents(fromMs: Long, toMs: Long): List<Triple<String, String, String>> {
        if (!granted(Manifest.permission.READ_CALENDAR)) return emptyList()
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, fromMs)
        ContentUris.appendId(b, toMs)
        val proj = arrayOf(
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.DESCRIPTION,
            CalendarContract.Instances.EVENT_LOCATION,
        )
        val out = ArrayList<Triple<String, String, String>>()
        try {
            contentResolver.query(b.build(), proj, null, null, CalendarContract.Instances.BEGIN + " ASC")?.use { c ->
                while (c.moveToNext()) out += Triple(c.getString(0).orEmpty(), c.getString(1).orEmpty(), c.getString(2).orEmpty())
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun joinMeeting() {
        val now = System.currentTimeMillis()
        val re = Regex("https://teams\\.(microsoft|live)\\.com/(l/meetup-join|meet)/[^\\s\"<>]+")
        val ev = calendarEvents(now - 15 * 60_000L, now + 60 * 60_000L)
            .firstNotNullOfOrNull { e -> re.find(e.second + " " + e.third)?.let { e.first to it.value } }
        if (ev == null) {
            val ok = Apps.findByName(this, "Teams")?.let { Apps.launch(this, it.packageName) } ?: false
            say(if (ok) "Non trovo il link della riunione nel calendario, apro Teams." else "Teams non è installato.")
        } else {
            say("Entro nella riunione ${ev.first}. Ricordati di spegnere la videocamera.") { Apps.openUrl(this, ev.second) }
        }
    }

    private fun nextAppointmentPlace(): String? {
        val now = System.currentTimeMillis()
        return calendarEvents(now, now + 12 * 3600_000L).firstOrNull { it.third.isNotBlank() && !it.third.contains("teams", true) }?.third
    }

    private fun openApp(name: String) {
        val app = Apps.findByName(this, name) ?: return say("Non trovo l'app $name.")
        Apps.launch(this, app.packageName)
        pausedUntil = System.currentTimeMillis() + 1500
    }

    private fun editBar(name: String, add: Boolean) {
        val app = Apps.findByName(this, name) ?: return say("Non trovo l'app $name.")
        val passenger = settings.mode == "passenger"
        val cur = if (passenger) settings.barPassenger else settings.bar
        val id = "app:" + app.packageName
        val next = if (add) (if (id in cur) cur else cur + id) else cur - id
        scope.launch { Prefs.setBar(applicationContext, passenger, next) }
        say(if (add) "Ho aggiunto ${app.label} alla barra." else "Ho tolto ${app.label} dalla barra.")
    }

    private fun whereIsCar() {
        if (settings.parkingTime == 0L) return say("Non ho ancora salvato un parcheggio.")
        bringToFront(Screen.PARKING)
        val here = Hub.location.value
        if (here == null) return say("Ecco dove hai parcheggiato.")
        val d = FloatArray(1)
        Location.distanceBetween(here.latitude, here.longitude, settings.parkingLat, settings.parkingLng, d)
        val txt = if (d[0] < 1000) "${(d[0] / 10).toInt() * 10} metri" else String.format(java.util.Locale.ITALIAN, "%.1f chilometri", d[0] / 1000)
        say("La macchina è a $txt da qui.")
    }

    private fun askGemini(q: String) {
        val key = settings.geminiKey
        if (key.isBlank()) {
            pausedUntil = System.currentTimeMillis() + 20_000
            try {
                startActivity(Intent(Intent.ACTION_VOICE_COMMAND).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                say("Non ho capito il comando.")
            }
            return
        }
        Hub.voice.value = Hub.voice.value.copy(phase = VoicePhase.THINKING)
        scope.launch {
            try {
                say(Gemini.ask(key, q))
                Hub.geminiError.value = null
            } catch (e: Gemini.GeminiException) {
                Hub.geminiError.value = e.detail
                say(e.spoken)
            } catch (e: Exception) {
                Hub.geminiError.value = e.message ?: e.javaClass.simpleName
                say("Gemini non è raggiungibile: controlla la connessione.")
            }
        }
    }

    // ---------------- posizione, autovelox, meteo ----------------

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val loc = result.lastLocation ?: return
            Hub.location.value = loc
            onLocation(loc)
        }
    }

    private fun startLocation() {
        if (!granted(Manifest.permission.ACCESS_FINE_LOCATION) && !granted(Manifest.permission.ACCESS_COARSE_LOCATION)) return
        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L).setMinUpdateIntervalMillis(500L).build()
        try {
            fused.requestLocationUpdates(req, locationCallback, Looper.getMainLooper())
        } catch (e: SecurityException) {
        }
    }

    private var camerasBusy = false

    private fun onLocation(loc: Location) {
        // meteo ogni 15 minuti o dopo 10 km
        val wp = lastWeatherPlace
        if (settings.weatherOn && (System.currentTimeMillis() - lastWeatherAt > 15 * 60_000L || (wp != null && wp.distanceTo(loc) > 10_000))) {
            lastWeatherAt = System.currentTimeMillis()
            lastWeatherPlace = loc
            scope.launch {
                try { Hub.weather.value = Weather.fetch(loc.latitude, loc.longitude) } catch (e: Exception) { }
            }
        }
        // autovelox
        if (!settings.cameras) {
            Hub.camera.value = null
            return
        }
        if (!camerasBusy) {
            camerasBusy = true
            scope.launch {
                try { SpeedCameras.refreshIfNeeded(loc) } catch (e: Exception) { } finally { camerasBusy = false }
            }
        }
        val hit = SpeedCameras.ahead(loc, settings.cameraWarnMeters)
        if (hit == null) {
            Hub.camera.value = null
            return
        }
        val (cam, dist) = hit
        Hub.camera.value = CameraAlert(dist, "Autovelox fisso", cam.maxSpeed)
        if (SpeedCameras.firstWarning(cam.id) && !alertsMuted) {
            when (settings.speedAlert) {
                "tone" -> speaker.beep(35)
                else -> {}
            }
        }
    }

    companion object {
        const val ACTION_LISTEN = "it.giacomo.tachimetro.LISTEN"
        const val ACTION_SAY = "it.giacomo.tachimetro.SAY"
        const val EXTRA_TEXT = "text"
        /** Quanto aspetta in silenzio prima di considerare finita la frase. */
        private const val PAUSE_MS = 3000L
        /** Se nessuno inizia a parlare dopo «Ehi Tachi», chiude l'ascolto da solo. */
        private const val NO_SPEECH_MS = 5500L
        private const val ANNOUNCE = 0
        private const val NAME_ONLY = 1
        private const val READ_NOW = 2

        @Volatile
        var running = false

        private val WAKE_WORDS = listOf("tachi", "tacchi", "taxi", "ta chi")
        private const val WAKE_GRAMMAR_LOW = "[\"ehi tachi\", \"ehi tacchi\", \"ehi taxi\", \"[unk]\"]"
        private const val WAKE_GRAMMAR_HIGH =
            "[\"ehi tachi\", \"ehi tacchi\", \"ehi taxi\", \"hey tacchi\", \"e tacchi\", \"ehi ta chi\", \"tacchi\", \"taxi\", \"tachi\", \"[unk]\"]"
        private const val WAKE_GRAMMAR =
            "[\"ehi tachi\", \"ehi tacchi\", \"ehi taxi\", \"hey tacchi\", \"e tacchi\", \"ehi ta chi\", \"[unk]\"]"

        fun start(context: Context) {
            if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
            context.startForegroundService(Intent(context, VoiceService::class.java))
        }

        fun listenNow(context: Context) {
            context.startService(Intent(context, VoiceService::class.java).setAction(ACTION_LISTEN))
        }
    }
}

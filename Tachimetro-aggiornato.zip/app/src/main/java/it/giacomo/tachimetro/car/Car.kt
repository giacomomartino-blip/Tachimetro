package it.giacomo.tachimetro.car

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import androidx.core.app.NotificationCompat
import it.giacomo.tachimetro.MainActivity
import it.giacomo.tachimetro.R
import it.giacomo.tachimetro.Screen
import it.giacomo.tachimetro.TachiApp
import it.giacomo.tachimetro.data.Keys
import it.giacomo.tachimetro.data.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

private val carScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

class ParkingReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Car.notify(context, 2, "Strisce blu", "Il parcheggio scade tra 10 minuti", Screen.PARKING)
    }
}

object Car {
    suspend fun saveParking(context: Context, loc: Location) {
        Prefs.edit(context) {
            it[Keys.parkingLat] = loc.latitude
            it[Keys.parkingLng] = loc.longitude
            it[Keys.parkingTime] = System.currentTimeMillis()
            it[Keys.parkingReminderAt] = 0L
        }
        notify(context, 3, "Parcheggio salvato", "Di' «Ehi Tachi, dov'è la macchina?» per ritrovarla", Screen.PARKING)
    }

    /** Imposta il promemoria 10 minuti prima della scadenza; ritorna 0 se il tempo non è superiore a 10 minuti. */
    fun setReminder(context: Context, minutes: Int): Long {
        if (minutes <= 10) return 0L
        val now = System.currentTimeMillis()
        val at = now + minutes * 60_000L
        val triggerAt = (at - 10 * 60_000L).coerceAtLeast(now + 10_000L)
        val am = context.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            context, 10, Intent(context, ParkingReminderReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }
        carScope.launch { Prefs.edit(context) { it[Keys.parkingReminderAt] = at } }
        return at
    }

    fun cancelReminder(context: Context) {
        val am = context.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            context, 10, Intent(context, ParkingReminderReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        am.cancel(pi)
        carScope.launch { Prefs.edit(context) { it[Keys.parkingReminderAt] = 0L } }
    }

    fun notify(context: Context, id: Int, title: String, text: String, screen: Screen) {
        if (context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val open = Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            .putExtra(MainActivity.EXTRA_SCREEN, screen.name)
        val pi = PendingIntent.getActivity(context, id, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(context, TachiApp.CH_CAR)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        context.getSystemService(NotificationManager::class.java).notify(id, n)
    }
}

package it.giacomo.tachimetro.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandParserTest {
    private val cases: List<Pair<String, (Command) -> Boolean>> = listOf(
        // Navigazione
        "portami a casa" to { c -> c is Command.Navigate && c.place == "@casa" && !c.waze },
        "portami al lavoro" to { c -> c is Command.Navigate && c.place == "@lavoro" },
        "imposta il percorso per Caserta" to { c -> c is Command.Navigate && c.place == "caserta" },
        "come arrivo a via Toledo" to { c -> c is Command.Navigate && c.place == "via toledo" },
        "portami all'ufficio postale in via Marmorata" to { c -> c is Command.Navigate && c.place == "ufficio postale in via marmorata" },
        "portami a casa con Waze" to { c -> c is Command.Navigate && c.place == "@casa" && c.waze },
        "partiamo" to { c -> c is Command.Go },
        "torna a Google Maps" to { c -> c is Command.BackToMaps },
        "ferma la navigazione" to { c -> c is Command.StopNavigation },
        "portami" to { c -> c is Command.Navigate && c.place.isBlank() },

        // Durante il viaggio
        "quanto manca" to { c -> c is Command.Eta },
        "dove sono" to { c -> c is Command.WhereAmI },
        "evita le autostrade" to { c -> c is Command.Avoid && c.highways && !c.tolls && c.enable },
        "evita i pedaggi" to { c -> c is Command.Avoid && !c.highways && c.tolls && c.enable },
        "togli evita autostrade" to { c -> c is Command.Avoid && !c.enable },
        "che tempo fa all'arrivo" to { c -> c is Command.WeatherAt && c.place == "@arrivo" },
        "ci sono autovelox" to { c -> c is Command.CameraAhead },

        // Ricerche di luoghi
        "ristorante cinese nelle vicinanze" to { c -> c is Command.SearchNearby && c.query == "ristorante cinese" && !c.best },
        "il miglior ristorante cinese qui vicino" to { c -> c is Command.SearchNearby && c.query == "ristorante cinese" && c.best },
        "cerca un negozio di scarpe" to { c -> c is Command.SearchNearby && c.query == "negozio di scarpe" },
        "dove trovo un ferramenta" to { c -> c is Command.SearchNearby && c.query == "ferramenta" },
        "trovami un gommista" to { c -> c is Command.SearchNearby && c.query == "gommista" },
        "portami alla farmacia più vicina" to { c -> c is Command.SearchNearby && c.query == "farmacia" },
        "c'è una farmacia aperta qui vicino" to { c -> c is Command.SearchNearby },

        // Messaggi
        "scrivi a Marco che arrivo tra dieci minuti" to { c -> c is Command.SendMessage && c.rest == "marco che arrivo tra dieci minuti" && c.app == null },
        "manda messaggio WhatsApp a Catia moglie" to { c -> c is Command.SendMessage && c.rest == "catia moglie" && c.app == "whatsapp" },
        "Manda un messaggio WhatsApp a Catia moglie che arrivo tra dieci minuti" to { c -> c is Command.SendMessage && c.rest == "catia moglie che arrivo tra dieci minuti" && c.app == "whatsapp" },
        "scrivi a Marco su WhatsApp che arrivo" to { c -> c is Command.SendMessage && c.rest == "marco che arrivo" && c.app == "whatsapp" },
        "manda un SMS a Luca" to { c -> c is Command.SendMessage && c.rest == "luca" && c.app == "sms" },
        "avvisa Marco che sono in ritardo" to { c -> c is Command.SendMessage && c.rest == "marco che sono in ritardo" },
        "puoi mandare un messaggio a mia moglie" to { c -> c is Command.SendMessage && c.rest == "moglie" },
        "manda un messaggio" to { c -> c is Command.SendMessage && c.rest.isBlank() },
        "chi manda messaggio whatsapp a Catia" to { c -> c is Command.SendMessage && c.rest == "catia" },
        "leggi gli ultimi messaggi WhatsApp" to { c -> c is Command.ReadMessages && c.app == "WhatsApp" && !c.onlyLast },
        "leggi l'ultimo messaggio" to { c -> c is Command.ReadMessages && c.onlyLast },
        "leggimi i messaggi" to { c -> c is Command.ReadMessages && c.app == null },
        "ci sono messaggi su Teams" to { c -> c is Command.ReadMessages && c.app == "Teams" },
        "chi mi ha scritto" to { c -> c is Command.ReadMessages },
        "rispondi" to { c -> c is Command.Reply },

        // Chiamate
        "chiama Luca" to { c -> c is Command.Call && c.name == "luca" && !c.whatsapp },
        "chiama Luca su WhatsApp" to { c -> c is Command.Call && c.name == "luca" && c.whatsapp },
        "mi puoi chiamare Catia moglie" to { c -> c is Command.Call && c.name == "catia moglie" },
        "richiama" to { c -> c is Command.CallBack },
        "rifiuta" to { c -> c is Command.HangUp },

        // Musica
        "metti Vasco su Spotify" to { c -> c is Command.PlayMusic && c.query == "vasco" && c.app == "spotify" },
        "metti la playlist viaggio" to { c -> c is Command.PlayMusic && c.query == "la playlist viaggio" },
        "pausa" to { c -> c is Command.Pause },
        "riprendi" to { c -> c is Command.Resume },
        "avanti" to { c -> c is Command.Next },
        "indietro" to { c -> c is Command.Previous },
        "alza il volume" to { c -> c is Command.Volume && c.up },
        "abbassa la musica" to { c -> c is Command.Volume && !c.up },
        "che canzone è" to { c -> c is Command.WhatIsPlaying },

        // Radio
        "metti Radio Deejay" to { c -> c is Command.PlayRadio && c.station == "deejay" },
        "radio RTL" to { c -> c is Command.PlayRadio && c.station == "rtl" },
        "passa a Radio 105" to { c -> c is Command.PlayRadio && c.station == "105" },
        "cerca radio Kiss Kiss" to { c -> c is Command.PlayRadio && c.station == "kiss kiss" },
        "radio locali" to { c -> c is Command.LocalRadio },
        "cambia radio" to { c -> c is Command.NextRadio },

        // Video & App
        "cerca Stranger Things su Netflix" to { c -> c is Command.SearchVideo && c.title == "stranger things" && c.app == "netflix" },
        "apri WhatsApp" to { c -> c is Command.OpenApp && c.name == "whatsapp" },
        "aggiungi Calendario alla barra" to { c -> c is Command.AddToBar && c.app == "calendario" },
        "togli Waze dalla barra" to { c -> c is Command.RemoveFromBar && c.app == "waze" },
        "entra nella riunione" to { c -> c is Command.JoinMeeting },

        // Auto
        "dov'è la macchina" to { c -> c is Command.WhereIsCar },
        "salva il parcheggio" to { c -> c is Command.SaveParking },
        "ricordami le strisce tra un'ora" to { c -> c is Command.Reminder && c.minutes == 60 },
        "ricordami le strisce blu fra un'ora e mezza" to { c -> c is Command.Reminder && c.minutes == 90 },
        "trova benzina qui vicino" to { c -> c is Command.FindFuel },
        "portami al primo distributore" to { c -> c is Command.Navigate && c.place == "@distributore" },
        "cerca un parcheggio" to { c -> c is Command.FindParking },

        // Informazioni
        "che ore sono" to { c -> c is Command.Time },
        "che tempo fa" to { c -> c is Command.WeatherAt && c.place == null },
        "che tempo fa a Napoli" to { c -> c is Command.WeatherAt && c.place == "napoli" },
        "quanta batteria ho" to { c -> c is Command.Battery },

        // Impostazioni & Modalità
        "attiva il non disturbare" to { c -> c is Command.SetPref && c.key == "dnd" && c.value == "true" },
        "disattiva la lettura dei messaggi" to { c -> c is Command.SetPref && c.key == "readMessages" && c.value == "false" },
        "spegni gli avvisi autovelox" to { c -> c is Command.SetPref && c.key == "cameras" && c.value == "false" },
        "tema notte" to { c -> c is Command.SetPref && c.key == "themeMode" && c.value == "night" },
        "sensibilità alta" to { c -> c is Command.SetPref && c.key == "wakeSensitivity" && c.value == "high" },
        "schermo intero" to { c -> c is Command.SetPref && c.key == "fullScreen" && c.value == "true" },
        "modalità passeggero" to { c -> c is Command.SetMode && !c.driver },
        "modalità guidatore" to { c -> c is Command.SetMode && c.driver },
        "silenzia avvisi" to { c -> c is Command.Mute },
        "impostazioni" to { c -> c is Command.Settings },
        "cruscotto" to { c -> c is Command.Dashboard },
        "chiudi Tachimetro" to { c -> c is Command.CloseApp },

        // Domande a Gemini vs frasi senza senso
        "chi ha vinto il campionato" to { c -> c is Command.AskGemini },
        "quanto è alto il Monte Bianco" to { c -> c is Command.AskGemini },
        "chi è il presidente della Repubblica" to { c -> c is Command.AskGemini },
        "cerca chi ha vinto la partita" to { c -> c is Command.AskGemini },
        "blabla patata" to { c -> c is Command.Unknown },
        "ciao" to { c -> c is Command.Unknown },
    )

    @Test
    fun frasi() {
        val wrong = cases.mapNotNull { (phrase, ok) ->
            val c = CommandParser.parse(phrase)
            if (ok(c)) null else "«$phrase» → $c"
        }
        assertTrue("Frasi capite male:\n" + wrong.joinToString("\n"), wrong.isEmpty())
    }

    @Test
    fun minuti() {
        assertEquals(30, CommandParser.minutes("mezz'ora"))
        assertEquals(45, CommandParser.minutes("tre quarti d'ora"))
        assertEquals(60, CommandParser.minutes("un'ora"))
        assertEquals(90, CommandParser.minutes("un'ora e mezza"))
        assertEquals(150, CommandParser.minutes("due ore e mezza"))
        assertEquals(45, CommandParser.minutes("45 minuti"))
    }
}
